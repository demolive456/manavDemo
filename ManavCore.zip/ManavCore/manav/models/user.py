import bcrypt
import sqlalchemy as sa

from manav.db.meta import Base

USERNAME_MIN_LENGTH = 3
USERNAME_MAX_LENGTH = 30
USERNAME_PATTERN = "(?i)^[A-Z0-9._]+$"

# class User(Base):
#     __tablename__ = "users"
#     id = sa.Column(sa.Integer, primary_key=True)
#     name = sa.Column(sa.Text, nullable=False, unique=True)
#     role = sa.Column(sa.Text, nullable=False)

#     password_hash = sa.Column(sa.UnicodeText(), nullable=True)


class User(Base):
    __tablename__ = "user"
    user_id = sa.Column(sa.Integer, primary_key=True)
    email_id = sa.Column(sa.VARCHAR, nullable=False, unique=True)
    password = sa.Column(sa.VARCHAR, nullable=False)

    #password_hash = sa.Column(sa.UnicodeText(), nullable=True)