

class UserJSONPresenter(object):
    """Present a user.

    Format a user's data in JSON for use in API services. Only include
    properties that are public-facing.
    """

    def __init__(self, user):
        self.user = user

    def asdict(self):
        return {
            "name": self.user.name,
            "role": self.user.role,
        }


class TrustedUserJSONPresenter(object):
    """Present a user to a trusted consumer.

    Format a user's data in JSON for use in API services, including any
    sensitive/private properties.
    """

    def __init__(self, user):
        self.user = user

    def asdict(self):
        user_presented = UserJSONPresenter(self.user).asdict()
        return user_presented
