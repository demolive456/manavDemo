from manav.models.user import (
    USERNAME_MIN_LENGTH,
    USERNAME_MAX_LENGTH,
    USERNAME_PATTERN,
)

from manav.schemas.base import JSONSchema

class CreateUserAPISchema(JSONSchema):
    """Validate a user JSON object."""

    schema = {
        "type": "object",
        "properties": {
            "name":{
                "type":"string"
            },
            "role": {"type": "string"},
            "password": {"type": "string"},
        },
        "anyOf": [
            {"required": ["name","role"]},

        ]
    }

    def validate(self, data):
        appstruct = super(CreateUserAPISchema,self).validate(data)
        return appstruct

class UserLoginAPISchema(JSONSchema):
    """Validate a user login JSON object. """

    schema ={
        "type":"object",
        "properties":{
            "username":{
                "type":"string"
            },
            "password":{"type": "string"}
        },
        "anyOf":[
            {"required":["username","password"]},
        ]
    }

    def validate(self,data):
        appstruct = super(UserLoginAPISchema,self).validate(data)
        return appstruct

