from passlib.context import CryptContext


password_context = CryptContext(
    schemes=["bcrypt"], bcrypt__ident="2b", bcrypt__min_rounds=12
)