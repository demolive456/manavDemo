
def includeme(config):
    config.register_service_factory(
        ".user.user_signup_service_factory", name="user_signup"
    )
    config.register_service_factory(
        ".user_password.user_password_service_factory", name="user_password"
    )
    config.register_service_factory(
        ".user.user_login_service_factory", name="user_login"
    )
    
