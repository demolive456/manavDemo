from manav.models import User
from sqlalchemy.exc import DBAPIError


class UserSignupService(object):
    def __init__(self, session, password_service):
        self.session = session
        self.password_service = password_service

    def signup(self, **kwargs):

        password = kwargs.pop("password",None)

        user = User(**kwargs)
        self.session.add(user)
        if password is not None:
            self.password_service.update_password(user,password)
            
        return user

# def user_signup_service_factory(context, request):
#     return UserSignupService ( 
#         session = request.dbsession ,
#         password_service = request.find_service(name="user_password")
#     )

class UserLoginService(object):
    def __init__(self, session,password_service):
        self.session = session
        self.password_service = password_service

    def login(self, **kwargs):
        username = kwargs.pop("username",None)
        lgn_password = kwargs.pop("password",None)

        user = self.session.query(User).filter(User.name==username).one_or_none()

        if username and lgn_password and user is not None:
            
            if self.password_service.verify_password(user,lgn_password):
               """
               Authentication token code service
               """
               oauth_svc = request.find_service(name="oauth_provider")
               
               
               return user
        return None

def user_login_service_factory(context, request):
    return UserLoginService (
        session = request.dbsession,
        password_service = request.find_service(name="user_password")
    )


class UserSignup(object):
    def __init__(self, **kwargs):
        self.request = kwargs['request']
        self.context = kwargs['context']

    def signup(self):
        session = self.request.dbsession
        email_id = self.request.json_body['email_id']
        password = self.request.json_body['password']
        try:
            user = User(email_id=email_id, password=password)
            execute = self.request.dbsession.add(user)
            self.request.dbsession.flush()
            # print(user.email_id)
            return user
        except DBAPIError as e:
            return e

def user_signup_service_factory(context, request):
    return UserSignup( 
        context = context,
        request = request
    )