import datetime

from manav.models import User
from manav.security import password_context

class UserPasswordService(object):
    """
    A service for checking and updating user passwords.

    """

    def __init__(self):
        self.hasher = password_context
      
    def update_password(self,user,new_password):
        """
        update the user password
        """

        user.salt = None
        user.password_hash = self.hasher.hash(new_password)

    def verify_password(self,user,password):
        """
        Verify password
        """
        verified = self.hasher.verify(password, user.password_hash)
        if verified:
            return True
        return False



def user_password_service_factory(context,request):
    """ Return UserPasswordService instance for the passed context and request """
    return UserPasswordService()
        