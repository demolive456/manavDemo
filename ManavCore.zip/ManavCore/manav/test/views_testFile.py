import unittest
from pyramid import testing
import transaction


class BaseTest(unittest.TestCase):
    def setUp(self):
        self.config = testing.setUp()
        self.config.include('..routes')

    def tearDown(self):
        testing.tearDown()

    ''' TEST register views '''
    def _call_registerView(self, request, method):
        from manav.views.register import RegisterView
        register = RegisterView(request)
        if method is 'GET' : return register.get()
        if method is 'POST' : return register.post()
        if method is 'DELETE' : return register.delete()

    def test_registerView(self):
        request = testing.DummyRequest(method='GET')
        response = self._call_registerView(request, 'GET')
        self.assertEqual(response, {"get":"success"})
        
        json_params = {'user':'apoorv', 'password': '12345'}
        request = testing.DummyRequest(json_body=json_params, method='POST')
        response = self._call_registerView(request, 'POST')
        self.assertEqual(response, {"post":"success"})

        request = testing.DummyRequest(json_body=json_params, method='DELETE')
        response = self._call_registerView(request, 'DELETE')
        self.assertEqual(response, {"delete":"success"})
        