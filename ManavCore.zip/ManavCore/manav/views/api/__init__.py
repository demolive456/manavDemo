
def includeme(config):
    config.scan(__name__)