from pyramid.view import view_defaults, view_config
from pyramid.response import Response
from pyramid.config import Configurator


'''
    GET, POST, PUT and DELETE methods for /register route

'''

@view_defaults(route_name='register', renderer = 'json')
class RegisterView(object):
    def __init__(self, context, request):
        self.context = context
        self.request = request
        # print(self.context)
    
    @view_config(request_method='GET')
    def get(self):
        return {"get":"success"}

    @view_config(request_method='POST')
    def post(self):
        req_data = self.request.json_body
        if req_data is not None:
            signObj = self.request.find_service(name="user_signup")
            db_return = signObj.signup()
            return {"post":db_return.email_id}

    @view_config(request_method='DELETE')
    def delete(self):
        return {"delete":"success"}