
from manav.schemas.user import CreateUserAPISchema, UserLoginAPISchema
from pyramid.view import view_config
from manav.presenters import TrustedUserJSONPresenter

@view_config(route_name='user.add', renderer = 'json')
def create(request):
    
    schema = CreateUserAPISchema()
    appstruct = schema.validate(_json_payload(request))

    
    user_signup_service = request.find_service(name="user_signup")
    user = user_signup_service.signup(**appstruct)
    presenter = TrustedUserJSONPresenter(user)
    return presenter.asdict()

@view_config(route_name= 'user.login', renderer = 'json')
def usr_login(request):

    schema = UserLoginAPISchema()
    appstruct = schema.validate(_json_payload(request))

    user_login_service = request.find_service(name="user_login")
    user = user_login_service.login(**appstruct)
    if user is not None:
        presenter = TrustedUserJSONPresenter(user)
        return presenter.asdict()
    return {}

def _json_payload(request):
    return request.json_body    


